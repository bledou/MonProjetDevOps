package consultation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

public class Database {
	String url = "jdbc:mysql://ls-0f19f4268096a452a869b6f8467bc299c51da519.cz6cgwgke8xd.eu-west-3.rds.amazonaws.com:3306/db0071448";
	String user = "user0071448";
	String password = "Yf3IgyBsOPa34WR";
	
	Connection conDB =  null;
	Statement stmt = null;
    ResultSet resultatS = null;
	
    //connexion à la base de donnée
    
	private void DatabaseConnexion() {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conDB = DriverManager.getConnection(url, user, password);
			if(conDB!=null) {
				System.out.println("connexion à la base de donnée a reuissi");
			}else {
				System.out.print("echec de connexion");
			}
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public Map<String, String> getEtudiant(String matricule) {
		
		DatabaseConnexion();
		
		Map<String, String> resultats = new HashMap<>();
		try {
			String query = "select * from etudiant where matricule =\""+matricule+"\";";
			conDB = DriverManager.getConnection(url, user, password);

	        // Créer un statement
	        stmt = conDB.createStatement();

	        // Exécuter la requête SQL
	        resultatS = stmt.executeQuery(query);
	        

	        if(resultatS.next()) {
	        	resultats.put("nom", resultatS.getString("nom"));
		        resultats.put("prenom", resultatS.getString("prenom"));
		        resultats.put("DateNais", resultatS.getString("DateNais"));
		        resultats.put("ecole", resultatS.getString("ecole"));
		        resultats.put("note", resultatS.getString("note"));
	        }

	        
		}catch (SQLException e) {
            System.out.println("Erreur de connexion ou d'exécution de la requête.");
            e.printStackTrace();
        } finally {
            // Fermer les ressources
            try {
                if (resultatS != null) resultatS.close();
                if (stmt != null) stmt.close();
                if (conDB != null) conDB.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
		
		
		return resultats;
	}
}
