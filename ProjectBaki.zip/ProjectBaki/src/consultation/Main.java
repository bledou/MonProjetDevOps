package consultation;


import java.util.HashMap;
import java.util.Map;

import javafx.application.Application;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {
	
	Map<String, String> _etudiant = new HashMap<>();

	@Override
	public void start(Stage primaryStage) throws Exception {
		
		// TODO Auto-generated method stub
		AnchorPane root = new AnchorPane();
		
		
		
		//creation de textfield pour entrer le matricule
		TextField zoneMatricule = new TextField("Veuillez entrer votre maticule ici");
		zoneMatricule.setStyle("-fx-font-size: 24px; -fx-font-family: 'Times New Roman';");
		
		//creation de bouton pour effectuer la recherche
		
		Button btnValider = new Button("VALIDER");
		btnValider.setStyle("-fx-padding: 10px; -fx-background-color: lightgreen;");
		btnValider.setMinSize(300, 25); // Largeur minimale de 50px, hauteur minimale de 20px
		btnValider.setMaxSize(400, 50);
		
		VBox vbox = new VBox(20);
		
		vbox.getChildren().addAll(zoneMatricule, btnValider);
		
		
		Label ll =  new Label("resultat");
		ll.setStyle("-fx-font-size: 15px;");
		
		Label labelResultat = new Label();
		labelResultat.setStyle("-fx-font-size: 40px;");
		
		Label labelNom = new Label();
		labelResultat.setStyle("-fx-font-size: 40px;");
		
		Label labelPrenom = new Label();
		labelResultat.setStyle("-fx-font-size: 40px;");
		
		Label labelDate = new Label();
		labelResultat.setStyle("-fx-font-size: 40px;");
		
		Label labelEcole = new Label();
		labelResultat.setStyle("-fx-font-size: 40px;");
		
		Label labelNote = new Label();
		labelResultat.setStyle("-fx-font-size: 40px;");
		
		Button btnDetail = new Button("AFFICHER LES DETAILS");
		btnDetail.setStyle("-fx-padding: 10px; -fx-background-color: lightblue;");
		btnDetail.setMinSize(300, 25); // Largeur minimale de 50px, hauteur minimale de 20px
		btnDetail.setMaxSize(400, 50);
		
		VBox vboxDetails = new VBox(9);
		vboxDetails.setAlignment(Pos.TOP_CENTER);
		
		
		AnchorPane zonecoordonnee =  new AnchorPane();
		zonecoordonnee.getChildren().add(vbox);
		
		zonecoordonnee.setTopAnchor(vbox, 20.0);
		zonecoordonnee.setRightAnchor(vbox, 20.0);
		zonecoordonnee.setBottomAnchor(vbox, 20.0);
		zonecoordonnee.setLeftAnchor(vbox, 20.0);
		
		//zone resultat
		AnchorPane zoneResultat = new AnchorPane();
		
		
		zoneResultat.getChildren().add(vboxDetails);
		
		zoneResultat.setTopAnchor(vboxDetails, 20.0);
		zoneResultat.setRightAnchor(vboxDetails, 20.0);
		zoneResultat.setBottomAnchor(vboxDetails, 20.0);
		zoneResultat.setLeftAnchor(vboxDetails, 20.0);
		
		
		SplitPane splitpane = new SplitPane();
		splitpane.setOrientation(Orientation.HORIZONTAL); // Ou Orientation.VERTICAL.setOrientation(Orientation.HORIZONTAL); // Ou Orientation.VERTICAL
		splitpane.getItems().addAll(zonecoordonnee, zoneResultat);
		splitpane.setDividerPositions(0.5);
		
		root.setTopAnchor(splitpane, 20.0);
		root.setRightAnchor(splitpane, 20.0);
		root.setBottomAnchor(splitpane, 0.0);
		root.setLeftAnchor(splitpane, 20.0);
		root.getChildren().add(splitpane);
		
		
		btnValider.setOnAction(event->{
			Database database =  new Database();
			_etudiant = database.getEtudiant(zoneMatricule.getText());
			
			if(zoneMatricule.getText()=="") {
				MonModal("Veuillez saisir un matricule");
			}else {
				
				
				
				if(_etudiant!=null) {
					int moyenne = Integer.parseInt(_etudiant.get("note"));
					if(moyenne>=10) {
						labelResultat.setText("SUCCES");
						vboxDetails.getChildren().addAll(ll, labelResultat, btnDetail);
					}else {
						labelResultat.setText("ECHEC");
						vboxDetails.getChildren().addAll(ll, labelResultat, btnDetail);
					}
					
				}else {
					MonModal("Désolé le matricule saisi n'existe pas");
				}
				
			}

		});
		
		
		btnDetail.setOnAction(event->{
			labelNom.setText(_etudiant.get("nom"));
			labelPrenom.setText(_etudiant.get("prenom"));
			labelDate.setText(_etudiant.get("DateNais"));
			labelEcole.setText(_etudiant.get("ecole"));
			labelNote.setText(_etudiant.get("note"));
			vboxDetails.getChildren().addAll(labelNom, labelPrenom, labelDate, labelEcole, labelNote);

		});
		
		
		Scene scene = new Scene(root, 900, 450);
		primaryStage.setScene(scene);
		primaryStage.setTitle("CONSULTATION");
		primaryStage.show();

	}
	
	public void MonModal(String message) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Information");
		alert.setHeaderText(null); // Pas de sous-titre
		alert.setContentText(message);

		// Affichage de l'alerte
		alert.showAndWait();
	}

	public static void main(String[] args) {
		
		launch();

	}

}
