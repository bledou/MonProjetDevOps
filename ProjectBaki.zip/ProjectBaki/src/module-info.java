/**
 * 
 */
/**
 * 
 */
module ProjectBaki3 {
	requires javafx.graphics;
	requires java.sql;
	requires javafx.controls;
}